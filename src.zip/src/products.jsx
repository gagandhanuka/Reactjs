

//export : to make this re usable in other classs/files 

//this/below can be considere as data model 
export class product
{

    pid;
    pname;
    pprice;
    isdeleted;

    //cosntructor is inbuilt function which invokes or execute automatically when object will create 
    constructor(id,name,price){

        this.pid = id
        this.pname = name
        this.price = price
        this.isdeleted= false
    }

    toggle(){

       this.isdeleted = !this.isdeleted

    }




}