import React, { Component } from 'react';


class Body extends React.Component {
    render() {
       return (
          <div>
             <h1>1111</h1>
          </div>
       );
    }
  }

  export default Body;