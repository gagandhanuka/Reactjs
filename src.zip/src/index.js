import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import {BrowserRouter, Route,Switch, Redirect} from 'react-router-dom';
import Header from './header';
import Footer from './footer';
import Main from './main';
class RoutedApp extends React.Component{
    render(){return(
    <BrowserRouter>
    <Switch>
        <Route exact path="/header" component={Header}/>
        <Route exact path="/footer" component={Footer}/>
        <Route exact path="/main" component={Main}/>
        <Route exact path="/" component={App}/>
        </Switch>
    </BrowserRouter>);}
}
ReactDOM.render(<App />, document.getElementById('root'));
registerServiceWorker();
