import React from 'react';

class Main extends React.Component{
    render(){
        return(
            <div className="menu">
              menu
           </div>
        );
    }
}

export default Main; 