import React from 'react'; 
import {BrowserRouter, Route,Switch, Redirect} from 'react-router-dom';
class Login extends React.Component{
    constructor(){
        super();
        this.state={
            emailid:"abc",
            password:"def",
            error1:true,
            error2:true,
          
            ondisable:true,
            error:true,
        }
    }
    emailf = (e) =>{
        
       if(e.target.value.length==0)
       {
            this.setState({error1:true})
       }
       else{
        this.setState({error1:false});
        
       }
    }

     passf = (e) =>{
        
       if(e.target.value.length==0)
       {
             this.setState({error2:true})
        }
        else{
            this.setState({error2:false})
        }
        
        if(!this.state.error1 && !this.state.error2){
                 this.state.ondisable=false;
         }
         else{
             this.state.ondisable=true;
         }
    }
    render(){
        return (
            <div>
                <form >
                <p>Email id:<input type="text" className={this.state.error1 ? "error":"text"}   onBlur={this.emailf}/></p>
                <p>Password<input className={this.state.error2 ? "error" : "text"} onChange={this.passf} type="password"/></p>
                <button onClick="" disabled={this.state.ondisable}>Login</button>
                </form>
            </div>
        )
    }
}
export default Login;