
//user library / function /class
//import product from './products'

//inbuilt or system defined library or drective 
import React, { Component } from 'react';
class productComponent extends React.Component {
    render() {
       return (
          <div>
             <h1>1111</h1>
          </div>
       );
    }
  }

export default productComponent;