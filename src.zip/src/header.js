import React from 'react';
import './App.css'; 
class Header extends React.Component{
    constructor(props)
    {
            super(props);  

            this.state={

                    products:[111,2,2,3,3,3444]
            }
            this.testEve = this.testEve.bind();

    }
    testEve()
    {
        alert("hi");

    }
    render(){
        return(
            <div className="header">{this.state.products.map(function(product,index) {
            return (<button onClick={this.testEve.bind()}>{product}</button>) },this)
                }
                {this.state.products}
            </div>
        );
    }
}

export default Header; 