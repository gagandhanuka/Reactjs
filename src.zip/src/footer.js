import React from 'react';
import './App.css'; 
class Footer extends React.Component{
    render(){
        return(
            <div className="footer">
                footer
            </div>
        );
    }
}

export default Footer; 