import React from 'react';
class Menu extends React.Component{

    constructor(props){

        super(props);
       
        
        this.state = {
            pid:'',
            pname:'',
            qty:'',
            showdata:'on submit',
            products:[],
            text:'pid      pname       qty',

        
        };
         this.handlebarPid = this.handlebarPid.bind(this);
         this.handlebarPname = this.handlebarPname.bind(this);
         this.handlebarQty = this.handlebarQty.bind(this);
         this.updateForm = this.updateForm.bind(this);
    }

   updateForm(e){
     this.state.products.push({pid: this.state.pid, pname:this.state.pname, qty:this.state.qty});
     console.log(this.state.products);
     this.setState(
         this.state
     )
     for(let i=0;i<this.state.products.length;i++){
    
        this.setState({text:<div>{this.state.text}<br/> {this.state.products[i].pid}{this.state.products[i].pname}{this.state.products[i].qty}</div>}
)

     }
  
     e.preventDefault();
   }


    handlebarPid(e){
    // this.setState({pid : e.target.value});
     this.setState({pid: e.target.value});
    }

    handlebarPname(e){
        this.setState({pname : e.target.value});
       }

       handlebarQty(e){
        this.setState({qty : e.target.value});
       }   
    

    render(){
        return(
            <div className="main">
      
             <form onSubmit={this.updateForm}>
             <p>PID
              <input type="text" onChange = {this.handlebarPid}/>
              </p>
                  <p>PName
              <input type="text" onChange = {this.handlebarPname}  />
              
              </p>
              <p>
              PQty
              <input type="text" onChange= {this.handlebarQty}  />
              
              </p>
              <p>
              <button type="submit">Submit</button>
              
              </p>

           </form>
           <h4 >{this.state.text}</h4>
          
           </div>
           
        );
    }
}

export default Menu; 


