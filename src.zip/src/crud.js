
import React from 'react';  
class crudApplication1 extends React.Component{

    constructor(props)
    {
            super(props);  

            this.testEve = this.testEve.bind();

    }
    testEve()
    {
        alert("hi");

    }
    render(){

        return(
                <div>
                            <button  onClick={this.testEve}>Click me </button>
                            <p>Hello World!</p>
                </div>


        );
    }
}

export default crudApplication1;
