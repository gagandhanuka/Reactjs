import React from 'react';
import TableComponent from'./mytable';
class Menu extends React.Component{

    constructor(props){

        super(props);
       
        
        this.state = {
            pid:'',
            pname:'',
            qty:'',
            showdata:'on submit',
            products:[],
            text:'pid      pname       qty',
            index:0,
            columns:['pid','pname','qty','action'],
            key:0,
        };
         this.handlebarPid = this.handlebarPid.bind(this);
         this.handlebarPname = this.handlebarPname.bind(this);
         this.handlebarQty = this.handlebarQty.bind(this);
         this.updateForm = this.updateForm.bind(this);
        this.deleteRow=this.deleteRow.bind(this);
        this.editRow=this.editRow.bind(this);
        this.DelAll=this.DelAll.bind(this);
    }

   updateForm(e){   
     this.state.products.push({pid: this.state.pid, pname:this.state.pname, qty:this.state.qty,flag:true});
     
     /*
     //fetch("http://localhost:3010/select?id=1141&name=%27hello%27&sal=1200000")
     fetch("http://localhost:3010/insert?id=1111&name='hello'&sal=1200000")
     .then(function(response) {
           // console.log(this.state.pid)
           // this.setState({pid:"Data Submitted"})
            console.log("Web Service called")
        
      })    
*/

     console.log(this.state.products);
     this.setState(
         this.state
     )
     e.preventDefault();

     }
     deleteRow(index){

        /*
        var dd  = this.state.products

        dd.splice(index,1);

        this.setState({products:dd})
        */
       

        this.state.products[index].flag=!this.state.products[index].flag
        
        this.setState({ key: Math.random() });
     }
     editRow(index){

         let proid=this.state.products[index].pid
         let proname=this.state.products[index].pname
         let proqty=this.state.products[index].qty
        this.setState({pid:proid})
        this.setState({pname:proname})
        this.setState({qty:proqty})
     }

DelAll()
{
    
    this.setState({products:this.state.products.filter( e=> e.flag ===true)})
    this.setState({ key: Math.random() });
    console.log(this.state.products)
    console.log(this.state.products.length)
    

}
    handlebarPid(e){
    // this.setState({pid : e.target.value});
     this.setState({pid: e.target.value});
    }

    handlebarPname(e){
        this.setState({pname : e.target.value});
       }

       handlebarQty(e){
        this.setState({qty : e.target.value});
       }   

    render(){    
        
        var dataColumns =this.state.columns;
        var dataRows = this.state.products;
    
        var tableHeaders = (<thead>
              <tr>
                {this.state.columns.map(function(column) {
                  return <th>{column}</th>; })}
              </tr>
          </thead>);
        
        var tableBody =this.state.products.map(function(row,index) {
          return (
  
                    <tr className={this.state.products[index].flag?"":"marked"}>
                      <td>{row.pid}</td>
                      <td>{row.pname}</td>
                      <td>{row.qty}</td>
                      <td><button onClick={(e)=>this.editRow(index)}>edit</button>  
                      <button onClick={(e)=>this.deleteRow(index)}>{this.state.products[index].flag?"Mark":"Unmark"}</button></td> 
                    
                    </tr>
                    
                  ); },this);
        return(<div>
            <div className="main">
      
             <form onSubmit={this.updateForm}>
             <p>PID
              <input type="text" value={this.state.pid}onChange = {this.handlebarPid}/>
              </p>
                  <p>PName
              <input type="text" value={this.state.pname}onChange = {this.handlebarPname}  />
              
              </p>
              <p>
              PQty
              <input type="text" value={this.state.qty}onChange= {this.handlebarQty}  />
              
              </p>
              <p>
              <button type="submit">Submit</button></p>
      
  
      
           </form>
           <p><button onClick={this.DelAll}>Delete</button>
              </p>

     <table border="2" width="100%" key={this.state.key}>
          {tableHeaders}
          <tbody>{tableBody}</tbody></table>
        {/* 
  <div id="table-component">
        <TableComponent data = {this.state.products} /></div>*/}
          </div> 
           </div>
        );
    }
}
export default Menu; 

