
import React, { Component } from 'react';
import Header from './header';
import Footer from './footer';
import Menu from './menu';
import Main from './main';
import Login from'./login';
//import logo from './logo.svg';
//import './App.css';
import crudApplication1 from './crud'


class App extends Component {

  constructor(){

    super();
    
    this.state = {

      header:"My First CRUD Application",
      about:"This will provider product management and sales functionalities"
    }
    this.updateState = this.updateState.bind(this);
  }
  
  updateState(e) {
 
    //this.setState({data: e.target.value});

    console.log("you have clicked;");

 }


  render() {
    return (
      <div className="App">
         
       <crudApplication/>

      <Header/>
      <div className="wrapper">
      <Menu className="menu"/>
      <Main className="main"/>
      </div>
      <Footer />
      </div>
    );
  }
}


export default App;
