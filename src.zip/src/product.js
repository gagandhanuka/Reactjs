import React, { Component } from 'react';


class Product extends React.Component {
    render() {
       return (
          <div>
             <h1>1111 =444</h1>
          </div>
       );
    }
  }

  export default Product;